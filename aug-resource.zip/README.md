# aug-resource
清理资源与插件
