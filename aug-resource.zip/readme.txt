流程说明：1.卸载aug 2.关闭vscode 3.清理工具清理 4.打开vscode安装插件 5.重启 6.登录

注意事项：
1.windows先双击执行清理工具.bat（清理工具.bat会把vscode所有缓存删除。或者使用windows高级清理工具.exe清理，该工具不影响vscode其他设置）
2.再把本插件(vscode-augment-0.524.1.vsix)拖到vscode里的插件安装区域安装（或者打开vscode，首先，从侧边栏中选择插件，然后点击右上方的三个点，再然后选择**“从VSIX中安装”**，之后会跳出地址栏，选择vscode-augment-0.524.1.vsix）。
重启vscode才可登录!重启vscode才可登录!重启vscode才可登录!
3.mac使用AugmentFree_v0.1.2_macos清理工具。
4.换账号时，一定要先退出账号，再重启vscode! 换账号时，一定要先退出账号，再重启vscode!换账号时，一定要先退出账号，再重启vscode!这样就才能在不需要清理数据同时，注册成功登录后不封号；不然也是几句话就封号
5.发货为邮箱验证码登录，验证码获取地址http://acg-mail-tool.getcharzp.cn/。输入邮箱账号密码获取验证码。不支持网页登录邮箱，只能用本店网址获取登录验证码，网址（http://acg-mail-tool.getcharzp.cn/）（输入账号密码点查询等待验证码过来即可）

注意：
不要点击网址（http://acg-mail-tool.getcharzp.cn/）中的微软链接。那是之前注册收到的邮件。收取augment验证码点击查询等待即可。如果未收到就需要重新发送验证码再查询几次。


说明：
账号需搭配定制版插件使用。vscode-augment-0.524.1.vsix是在官方基础上增加了防封功能，其余与官方完全一致。

